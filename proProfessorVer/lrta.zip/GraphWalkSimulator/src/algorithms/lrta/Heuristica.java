package algorithms.lrta;

public class Heuristica {
	public int nodeId;
	public int heuristica;

	public Heuristica(int nodeId, int heuristica) {
		this.nodeId = nodeId;
		this.heuristica = heuristica;
	}

}